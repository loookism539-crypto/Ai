# Sonu — Your AI Friend

A polished, mobile-first AI chat app using the Sonu kitten logo. It can run as a web app/PWA and be installed on Android from a browser after deployment.

## Run it

1. Install Node.js 20+.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your API key in `.env` as `OPENAI_API_KEY=...`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

Without an API key, Sonu runs in a small demo mode so you can preview the interface.

## Important

Keep the API key on the server. Do not put it into the browser JavaScript. The app uses the OpenAI Responses API through the official JavaScript SDK.

## Features

- Sonu branding and custom kitten logo
- ChatGPT-style conversation UI
- Mobile-first responsive design
- Installable PWA
- Voice input when supported by the browser
- Optional web-search toggle
- New chat / clear chat
- Quick actions: Explain, Plan, Create, Learn
- Demo mode when no API key is configured

## Make it a real Android app

Deploy this Node app to a HTTPS host, open it on Android Chrome, and use the browser's **Add to Home screen / Install app** option. For a Play Store APK/AAB, wrap the same HTTPS PWA in an Android WebView/TWA project.
