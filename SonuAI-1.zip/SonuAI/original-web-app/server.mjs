import express from 'express';
import OpenAI from 'openai';
import dotenv from 'dotenv';

dotenv.config();
const app = express();
const port = process.env.PORT || 3000;
const model = process.env.SONU_MODEL || 'gpt-5.6-luna';
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.use(express.json({ limit: '2mb' }));
app.use(express.static('public'));

const instructions = `You are Sonu, a warm, smart, friendly AI assistant. Your name is Sonu. Be helpful, concise when the user wants a quick answer, and detailed when useful. You can help with learning, writing, coding, planning, brainstorming, explanations, and everyday questions. Never claim to be human. Keep a friendly tone and use the user's language when practical.`;

app.post('/api/chat', async (req, res) => {
  try {
    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const useWeb = Boolean(req.body?.useWeb);
    if (!messages.length) return res.status(400).json({ error: 'No messages provided.' });
    if (!client) return res.json({ demo: true, text: demoReply(messages.at(-1)?.content || '') });

    const body = {
      model,
      instructions,
      input: messages.slice(-24).map(m => ({
        role: m.role === 'assistant' ? 'assistant' : 'user',
        content: String(m.content || '')
      })),
      store: false
    };
    if (useWeb) body.tools = [{ type: 'web_search' }];

    const response = await client.responses.create(body);
    res.json({ text: response.output_text || 'I could not generate a response.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err?.message || 'Sonu could not respond.' });
  }
});

function demoReply(text) {
  const t = text.toLowerCase();
  if (t.includes('hello') || t.includes('hi')) return 'Hi! I’m Sonu 👋 Add your OpenAI API key to turn on my full AI brain. For now, I’m running in demo mode.';
  if (t.includes('who are you')) return 'I’m Sonu — your AI friend. 🤖🐱';
  return `I’m Sonu! I received: “${text}”. Connect an OpenAI API key in .env to get full AI answers.`;
}

app.listen(port, () => console.log(`Sonu is running at http://localhost:${port}`));
