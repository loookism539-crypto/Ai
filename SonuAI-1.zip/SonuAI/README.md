# Sonu AI — Android Studio Project

Sonu is a native Android shell around the original Sonu web UI, with a local WebView, native voice input, an in-app OpenAI API connection, web-search mode, Sonu branding, and the supplied kitten logo.

## Build the APK

1. Install Android Studio (recent stable version).
2. Open **this `SonuAI` folder** in Android Studio.
3. Allow Gradle to sync and install any requested Android SDK components.
4. Select **Build → Generate App Bundle(s) / APK(s) → Generate APK(s)**.
5. Android Studio will show the generated APK location.

The project is configured for:
- Application ID: `com.sonu.ai`
- App name: `Sonu`
- Min Android: 8.0 (API 26)
- Target/compile SDK: 35
- Gradle: 8.10.2
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21

## Connect the AI

The first time Sonu opens, it asks for an OpenAI API key and model. The default model is `gpt-5.6-luna`.

You can later open the ⚙ button in Sonu to change the key/model.

**Security note:** This version stores the API key locally on the device because the app calls the API directly. Do not hard-code a personal API key into a distributed APK. For a public Play Store release, put the OpenAI call behind your own authenticated server so the API key is never shipped to users.

## Features included

- Sonu dark neon interface
- Supplied Sonu kitten logo
- Chat history for the current conversation
- New chat / clear chat
- Native Android speech recognition
- Web-search toggle through the Responses API
- OpenAI Responses API connection
- Offline-friendly UI/demo shell when no API key is configured

## Notes

The Gradle wrapper properties are included so Android Studio can use Gradle 8.10.2. This environment does not include the Android SDK/Gradle build toolchain, so the APK itself was not compiled here.
