# Sonu currently ships without code shrinking. Add project-specific rules here if needed.
