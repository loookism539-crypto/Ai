package com.sonu.ai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("sonu_prefs", MODE_PRIVATE) }
    private val voiceRequestCode = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(4, 8, 20)
        window.navigationBarColor = Color.rgb(3, 6, 16)

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(4, 8, 20))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(SonuBridge(), "SonuAndroid")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)

        if (prefs.getString("api_key", "").isNullOrBlank()) {
            webView.postDelayed({ showSettings(true) }, 650)
        }
    }

    inner class SonuBridge {
        @JavascriptInterface
        fun ask(payload: String) {
            val key = prefs.getString("api_key", "")?.trim().orEmpty()
            if (key.isBlank()) {
                runOnUiThread { showSettings(false) }
                return
            }
            executor.execute {
                val result = try { callOpenAI(key, JSONObject(payload)) }
                catch (e: Exception) { JSONObject().put("error", e.message ?: "Sonu could not respond.") }
                val ok = !result.has("error")
                val safe = JSONObject.quote(result.toString())
                runOnUiThread {
                    webView.evaluateJavascript("window.onNativeReply($ok,$safe);", null)
                }
            }
        }

        @JavascriptInterface
        fun openSettings() = runOnUiThread { showSettings(false) }

        @JavascriptInterface
        fun startVoice() = runOnUiThread {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), voiceRequestCode)
                return@runOnUiThread
            }
            launchVoice()
        }
    }

    private fun launchVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Sonu")
        }
        try { startActivityForResult(intent, voiceRequestCode) }
        catch (_: Exception) { sendStatus("Voice input is not available on this device") }
    }

    @Deprecated("Android activity result API retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequestCode && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            val js = "window.setVoiceText(${JSONObject.quote(text)});"
            webView.evaluateJavascript(js, null)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == voiceRequestCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) launchVoice()
        else if (requestCode == voiceRequestCode) sendStatus("Microphone permission is required for voice input")
    }

    private fun showSettings(firstRun: Boolean) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(55, 5, 55, 0)
        }
        val intro = TextView(this).apply {
            text = "Connect Sonu to the OpenAI API. Your key is stored only on this device.\n\nCreate an API key in your OpenAI developer account, then paste it below."
            setTextColor(Color.DKGRAY)
            textSize = 14f
            setPadding(0, 0, 0, 18)
        }
        val key = EditText(this).apply {
            hint = "sk-..."
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        val model = EditText(this).apply {
            hint = "Model"
            setText(prefs.getString("model", "gpt-5.6-luna"))
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        box.addView(intro)
        box.addView(key)
        box.addView(model)

        AlertDialog.Builder(this)
            .setTitle("Sonu Settings")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("api_key", key.text.toString().trim()).putString("model", model.text.toString().trim().ifBlank { "gpt-5.6-luna" }).apply()
                sendStatus("Sonu is ready ✨")
            }
            .apply { if (!firstRun) setNegativeButton("Cancel", null) }
            .show()
    }

    private fun sendStatus(text: String) {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript("window.onNativeStatus(${JSONObject.quote(text)});", null)
    }

    private fun callOpenAI(apiKey: String, payload: JSONObject): JSONObject {
        val messages = payload.optJSONArray("messages") ?: JSONArray()
        val body = JSONObject()
            .put("model", prefs.getString("model", "gpt-5.6-luna"))
            .put("instructions", "You are Sonu, a warm, smart, friendly AI assistant. Your name is Sonu. Be helpful, concise when the user wants a quick answer, and detailed when useful. You can help with learning, writing, coding, planning, brainstorming, explanations, and everyday questions. Never claim to be human. Keep a friendly tone and use the user's language when practical.")
            .put("input", messages)
            .put("store", false)
        if (payload.optBoolean("useWeb", false)) body.put("tools", JSONArray().put(JSONObject().put("type", "web_search")))

        val connection = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30000
            readTimeout = 90000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
        }
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) {
            val msg = try { JSONObject(text).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
            throw IllegalStateException(msg?.takeIf { it.isNotBlank() } ?: "OpenAI request failed ($code)")
        }
        val json = JSONObject(text)
        val outputText = json.optString("output_text", "").trim()
        if (outputText.isNotBlank()) return JSONObject().put("text", outputText)
        val fallback = extractOutputText(json)
        return JSONObject().put("text", fallback.ifBlank { "I could not generate a response." })
    }

    private fun extractOutputText(json: JSONObject): String {
        val output = json.optJSONArray("output") ?: return ""
        val result = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                val t = part.optString("text", "")
                if (t.isNotBlank()) {
                    if (result.isNotEmpty()) result.append('\n')
                    result.append(t)
                }
            }
        }
        return result.toString()
    }

    override fun onDestroy() {
        executor.shutdownNow()
        webView.destroy()
        super.onDestroy()
    }
}
